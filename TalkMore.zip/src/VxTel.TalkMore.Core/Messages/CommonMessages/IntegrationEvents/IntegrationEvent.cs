﻿namespace VxTel.TalkMore.Core.Messages.CommonMessages.IntegrationEvents
{
	public abstract class IntegrationEvent : Event
	{
	}
}