﻿namespace VxTel.TalkMore.Core.Contracts
{
	public interface IAggregateRoot
	{
	}
}