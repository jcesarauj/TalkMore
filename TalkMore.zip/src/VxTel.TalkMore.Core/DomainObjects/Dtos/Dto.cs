﻿namespace VxTel.TalkMore.Core.DomainObjects.Dtos
{
	public class Dto
	{
	}
}