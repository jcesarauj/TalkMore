﻿namespace VxTel.TalkMore.Application.Plan
{
	public class PlanDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}
}