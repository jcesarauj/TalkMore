﻿using TechTalk.SpecFlow;

namespace VxTel.TalkMore.Data.Tests
{
	[Binding]
	public class CalcularValorDaLigacaoSteps
	{
		[Given(@"que o utilizador informou os dados no formulario")]
		public void DadoQueOUtilizadorInformouOsDadosNoFormulario()
		{
			//Arrange

			//Act

			//Assert
		}

		[When(@"clicar em calcular")]
		public void QuandoClicarEmCalcular()
		{
			//Arrange

			//Act

			//Assert
		}

		[Then(@"O valor dos planos FaleMais deve ser calculado e exibido para o usuário")]
		public void EntaoOValorDosPlanosFaleMaisDeveSerCalculadoEExibidoParaOUsuario()
		{
			//Arrange

			//Act

			//Assert
		}
	}
}